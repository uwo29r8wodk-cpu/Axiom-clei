package com.axiom.client.modules.impl.movement;

import com.axiom.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerAbilities;
import org.lwjgl.glfw.GLFW;

/**
 * Fly – enables creative-style flight in survival mode.
 *
 * Note: This modifies the client-side PlayerAbilities.
 * On servers with anti-cheat this will be detected and reversed.
 * Intended for single-player or permissive servers only.
 */
public class Fly extends Module {

    private static final float FLY_SPEED = 0.05f;

    public Fly() {
        super("Fly", "Enables creative-like flight", Category.MOVEMENT, GLFW.GLFW_KEY_G);
    }

    @Override
    public void onEnable() {
        if (mc.player == null) return;
        PlayerAbilities abilities = mc.player.getAbilities();
        abilities.allowFlying = true;
        abilities.flying      = true;
        abilities.setFlySpeed(FLY_SPEED);
    }

    @Override
    public void onDisable() {
        if (mc.player == null) return;
        // Only remove fly if not in creative/spectator
        if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            PlayerAbilities abilities = mc.player.getAbilities();
            abilities.allowFlying = false;
            abilities.flying      = false;
            abilities.setFlySpeed(0.05f); // vanilla default
        }
    }
}
