package com.axiom.client.gui.components;

import com.axiom.client.gui.ClickGUI;
import com.axiom.client.modules.Module;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/**
 * CategoryPanel – a draggable panel that displays all modules in one category.
 *
 * Structure:
 *   ┌────────────────────┐  ← title bar (drag handle)
 *   │  CATEGORY NAME     │
 *   ├────────────────────┤
 *   │  [●] ModuleName    │  ← ModuleButton rows
 *   │  [○] ModuleName2   │
 *   └────────────────────┘
 */
public class CategoryPanel {

    // ── Layout constants ───────────────────────────────────────────────────
    private static final int HEADER_HEIGHT = 18;
    private static final int ROW_HEIGHT    = 14;
    private static final int PADDING       = 4;

    // ── Identity ───────────────────────────────────────────────────────────
    private final Module.Category   category;
    private final List<ModuleButton> buttons = new ArrayList<>();

    // ── Position & size ────────────────────────────────────────────────────
    private int x, y;
    private final int width;

    // ── Drag state ─────────────────────────────────────────────────────────
    private boolean dragging    = false;
    private double  dragOffsetX = 0;
    private double  dragOffsetY = 0;

    // ─────────────────────────────────────────────────────────────────────
    public CategoryPanel(Module.Category category, List<Module> modules,
                         int x, int y, int width) {
        this.category = category;
        this.x = x;
        this.y = y;
        this.width = width;

        // Build one button per module
        for (int i = 0; i < modules.size(); i++) {
            int buttonY = y + HEADER_HEIGHT + i * ROW_HEIGHT;
            buttons.add(new ModuleButton(modules.get(i), x, buttonY, width, ROW_HEIGHT));
        }
    }

    // ── Rendering ──────────────────────────────────────────────────────────

    public void render(DrawContext ctx, TextRenderer font, int mouseX, int mouseY) {
        int totalHeight = HEADER_HEIGHT + buttons.size() * ROW_HEIGHT;

        // Panel background
        ctx.fill(x, y, x + width, y + totalHeight, ClickGUI.COL_BG);

        // Header bar
        ctx.fill(x, y, x + width, y + HEADER_HEIGHT, ClickGUI.COL_PANEL_HDR);

        // Coloured accent strip on the left of the header
        int catColor = 0xFF000000 | category.color;
        ctx.fill(x, y, x + 3, y + HEADER_HEIGHT, catColor);

        // Category name centred in header
        String title = category.displayName.toUpperCase();
        int titleX = x + (width - font.getWidth(title)) / 2;
        ctx.drawTextWithShadow(font, title, titleX, y + (HEADER_HEIGHT - 8) / 2,
                               ClickGUI.COL_TEXT);

        // Module buttons — update their Y positions in case panel was dragged
        for (int i = 0; i < buttons.size(); i++) {
            ModuleButton btn = buttons.get(i);
            btn.setPosition(x, y + HEADER_HEIGHT + i * ROW_HEIGHT);
            btn.render(ctx, font, mouseX, mouseY);
        }

        // Bottom border line
        ctx.fill(x, y + totalHeight - 1, x + width, y + totalHeight,
                 0xFF000000 | category.color);
    }

    // ── Mouse input ────────────────────────────────────────────────────────

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Check if click is on the header → start drag
        if (button == 0 && isInHeader(mouseX, mouseY)) {
            dragging    = true;
            dragOffsetX = mouseX - x;
            dragOffsetY = mouseY - y;
            return true;
        }

        // Forward to buttons
        for (ModuleButton btn : buttons) {
            if (btn.mouseClicked(mouseX, mouseY, button)) {
                return true;
            }
        }
        return false;
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button,
                                double deltaX, double deltaY) {
        if (dragging && button == 0) {
            x = (int) (mouseX - dragOffsetX);
            y = (int) (mouseY - dragOffsetY);
            return true;
        }
        return false;
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private boolean isInHeader(double mx, double my) {
        return mx >= x && mx <= x + width && my >= y && my <= y + HEADER_HEIGHT;
    }
}
