package com.axiom.client;

import com.axiom.client.config.ConfigManager;
import com.axiom.client.events.EventBus;
import com.axiom.client.gui.ClickGUI;
import com.axiom.client.modules.ModuleManager;
import com.axiom.client.utils.Logger;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * AxiomClient - Main entry point for the Axiom Client mod.
 *
 * Initialization order:
 *   1. EventBus     – pub/sub system for mod events
 *   2. ModuleManager – registers all feature modules
 *   3. ConfigManager – loads saved settings from disk
 *   4. ClickGUI     – builds the in-game GUI
 *
 * The GUI keybind (default: RIGHT_SHIFT) is registered here via
 * Fabric's KeyBindingHelper and polled every client tick.
 */
public class AxiomClient implements ClientModInitializer {

    // ── Singleton ──────────────────────────────────────────────────────────────
    private static AxiomClient INSTANCE;

    /** @return the single live instance of the client */
    public static AxiomClient getInstance() { return INSTANCE; }

    // ── Core systems ───────────────────────────────────────────────────────────
    private EventBus      eventBus;
    private ModuleManager moduleManager;
    private ConfigManager configManager;
    private ClickGUI      clickGUI;

    /** Keybind that opens/closes the ClickGUI overlay */
    private KeyBinding guiKeybind;

    // ── Client name displayed in the HUD / loading screen ─────────────────────
    public static final String CLIENT_NAME    = "Axiom";
    public static final String CLIENT_VERSION = "1.0.0";

    // ──────────────────────────────────────────────────────────────────────────
    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        Logger.info("Initialising " + CLIENT_NAME + " v" + CLIENT_VERSION);

        // 1. Event bus – must be first so other systems can subscribe immediately
        eventBus = new EventBus();

        // 2. Modules
        moduleManager = new ModuleManager();
        moduleManager.registerModules();

        // 3. Config (loads after modules exist so it can apply saved state)
        configManager = new ConfigManager();
        configManager.load();

        // 4. GUI
        clickGUI = new ClickGUI();

        // Register the GUI toggle keybind (Right Shift)
        guiKeybind = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.axiom.opengui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.axiom"
        ));

        // Poll keybind every tick
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);

        Logger.info(CLIENT_NAME + " initialised successfully!");
    }

    /**
     * Called once per client tick.
     * - Fires the module manager tick
     * - Opens the ClickGUI when the keybind is pressed
     */
    private void onClientTick(MinecraftClient client) {
        // Dispatch tick to all enabled modules
        moduleManager.onTick(client);

        // Open GUI on keybind press
        if (guiKeybind.wasPressed() && client.player != null) {
            client.setScreen(clickGUI);
        }
    }

    // ── Getters ───────────────────────────────────────────────────────────────
    public EventBus      getEventBus()      { return eventBus; }
    public ModuleManager getModuleManager() { return moduleManager; }
    public ConfigManager getConfigManager() { return configManager; }
    public ClickGUI      getClickGUI()      { return clickGUI; }
}
