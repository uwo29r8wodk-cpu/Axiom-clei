package com.axiom.client.events;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * EventBus – lightweight publish/subscribe system.
 *
 * Modules subscribe to event types; the bus dispatches to all listeners
 * when an event is posted.
 *
 * Usage:
 *   EventBus bus = AxiomClient.getInstance().getEventBus();
 *   bus.subscribe(RenderEvent.class, e -> doSomething(e));
 *   bus.post(new RenderEvent(matrices, tickDelta));
 */
public class EventBus {

    // Map from event class → list of listener callbacks
    private final Map<Class<?>, List<Consumer<Object>>> listeners = new HashMap<>();

    /**
     * Subscribe a listener for a specific event type.
     *
     * @param eventClass The class of the event to listen for
     * @param listener   Callback invoked when that event is posted
     */
    @SuppressWarnings("unchecked")
    public <T> void subscribe(Class<T> eventClass, Consumer<T> listener) {
        listeners
            .computeIfAbsent(eventClass, k -> new ArrayList<>())
            .add((Consumer<Object>) listener);
    }

    /**
     * Remove all listeners for a given event type.
     * Call this when a module is disabled to prevent memory leaks.
     */
    public <T> void unsubscribeAll(Class<T> eventClass) {
        listeners.remove(eventClass);
    }

    /**
     * Post (publish) an event to all registered listeners.
     *
     * @param event The event object to dispatch
     */
    public void post(Object event) {
        List<Consumer<Object>> list = listeners.get(event.getClass());
        if (list != null) {
            for (Consumer<Object> listener : list) {
                try {
                    listener.accept(event);
                } catch (Exception e) {
                    // Never let a bad listener crash the game
                    com.axiom.client.utils.Logger.error(
                        "EventBus error in listener for " + event.getClass().getSimpleName()
                        + ": " + e.getMessage()
                    );
                }
            }
        }
    }
}
