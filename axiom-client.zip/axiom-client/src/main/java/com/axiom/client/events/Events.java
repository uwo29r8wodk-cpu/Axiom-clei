package com.axiom.client.events;

import net.minecraft.client.util.math.MatrixStack;

/**
 * Events posted by mixins so modules can hook into the render pipeline.
 * All inner classes are simple data holders — no logic here.
 */
public class Events {

    // ── Render events ─────────────────────────────────────────────────────────

    /** Posted every frame by GameRendererMixin (before game renders). */
    public static class RenderTickEvent {
        public final MatrixStack matrices;
        public final float tickDelta;
        public RenderTickEvent(MatrixStack matrices, float tickDelta) {
            this.matrices  = matrices;
            this.tickDelta = tickDelta;
        }
    }

    /** Posted by WorldRendererMixin when the world is being rendered. */
    public static class WorldRenderEvent {
        public final MatrixStack matrices;
        public final float tickDelta;
        public WorldRenderEvent(MatrixStack matrices, float tickDelta) {
            this.matrices  = matrices;
            this.tickDelta = tickDelta;
        }
    }

    /** Posted by InGameHudMixin after the vanilla HUD has drawn. */
    public static class HudRenderEvent {
        public final MatrixStack matrices;
        public final float tickDelta;
        public HudRenderEvent(MatrixStack matrices, float tickDelta) {
            this.matrices  = matrices;
            this.tickDelta = tickDelta;
        }
    }

    // ── Input events ──────────────────────────────────────────────────────────

    /** Posted by KeyboardMixin when a key is pressed. */
    public static class KeyPressEvent {
        public final int key;
        public final int action; // GLFW_PRESS, GLFW_RELEASE, GLFW_REPEAT
        public KeyPressEvent(int key, int action) {
            this.key    = key;
            this.action = action;
        }
    }

    // ── Tick events ───────────────────────────────────────────────────────────

    /** Posted every client tick by AxiomClient. */
    public static class ClientTickEvent { }
}
