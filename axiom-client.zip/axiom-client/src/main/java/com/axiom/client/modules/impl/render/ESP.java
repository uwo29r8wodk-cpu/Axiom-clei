package com.axiom.client.modules.impl.render;

import com.axiom.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.math.Box;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

/**
 * ESP (Extra Sensory Perception) – draws colored outlines around entities
 * so you can see them through terrain.
 *
 * Rendering approach: we draw axis-aligned bounding boxes (AABB) in the
 * world using line primitives submitted to the Tessellator. This is purely
 * visual and client-side only.
 *
 * Colors:
 *   Players  → red   (0xFF, 0x33, 0x33)
 *   Mobs     → orange (0xFF, 0xAA, 0x00)
 *   Other    → white  (0xFF, 0xFF, 0xFF)
 */
public class ESP extends Module {

    public ESP() {
        super("ESP", "Draws outlines around nearby entities", Category.RENDER, GLFW.GLFW_KEY_Z);
    }

    /**
     * Draw ESP boxes for all loaded entities.
     * Called from WorldRendererMixin after the world is rendered.
     *
     * @param matrices  the current MatrixStack
     * @param tickDelta partial tick for smooth interpolation
     */
    public void render(MatrixStack matrices, float tickDelta) {
        if (mc.world == null || mc.player == null) return;

        // Camera position used to translate entity coords into view space
        Camera camera = mc.gameRenderer.getCamera();
        double camX = camera.getPos().x;
        double camY = camera.getPos().y;
        double camZ = camera.getPos().z;

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buf = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES,
                VertexFormats.POSITION_COLOR);

        matrices.push();
        // Translate world origin to camera position
        matrices.translate(-camX, -camY, -camZ);

        Matrix4f matrix = matrices.peek().getPositionMatrix();

        for (Entity entity : mc.world.getEntities()) {
            // Skip the local player and non-living entities
            if (entity == mc.player) continue;
            if (!entity.isAlive()) continue;

            // Choose colour based on entity type
            float r, g, b;
            if (entity instanceof PlayerEntity) {
                r = 1.0f; g = 0.2f; b = 0.2f; // red
            } else if (entity instanceof MobEntity) {
                r = 1.0f; g = 0.67f; b = 0.0f; // orange
            } else {
                r = 1.0f; g = 1.0f; b = 1.0f; // white
            }

            // Interpolate bounding box position for smooth movement
            double x = entity.lastRenderX + (entity.getX() - entity.lastRenderX) * tickDelta;
            double y = entity.lastRenderY + (entity.getY() - entity.lastRenderY) * tickDelta;
            double z = entity.lastRenderZ + (entity.getZ() - entity.lastRenderZ) * tickDelta;

            Box box = entity.getBoundingBox().offset(
                    x - entity.getX(),
                    y - entity.getY(),
                    z - entity.getZ()
            );

            drawOutlinedBox(buf, matrix, box, r, g, b, 1.0f);
        }

        // Submit all lines to the GPU
        try {
            BufferRenderer.drawWithGlobalProgram(buf.end());
        } catch (Exception ignored) {
            // Buffer may be empty if no entities in range — safe to ignore
        }

        matrices.pop();
    }

    /**
     * Adds the 12 edges of an AABB as line vertices to the given buffer.
     */
    private void drawOutlinedBox(BufferBuilder buf, Matrix4f matrix,
                                  Box box, float r, float g, float b, float a) {
        float x1 = (float) box.minX, y1 = (float) box.minY, z1 = (float) box.minZ;
        float x2 = (float) box.maxX, y2 = (float) box.maxY, z2 = (float) box.maxZ;

        // Bottom face
        line(buf, matrix, x1,y1,z1, x2,y1,z1, r,g,b,a);
        line(buf, matrix, x2,y1,z1, x2,y1,z2, r,g,b,a);
        line(buf, matrix, x2,y1,z2, x1,y1,z2, r,g,b,a);
        line(buf, matrix, x1,y1,z2, x1,y1,z1, r,g,b,a);

        // Top face
        line(buf, matrix, x1,y2,z1, x2,y2,z1, r,g,b,a);
        line(buf, matrix, x2,y2,z1, x2,y2,z2, r,g,b,a);
        line(buf, matrix, x2,y2,z2, x1,y2,z2, r,g,b,a);
        line(buf, matrix, x1,y2,z2, x1,y2,z1, r,g,b,a);

        // Vertical edges
        line(buf, matrix, x1,y1,z1, x1,y2,z1, r,g,b,a);
        line(buf, matrix, x2,y1,z1, x2,y2,z1, r,g,b,a);
        line(buf, matrix, x2,y1,z2, x2,y2,z2, r,g,b,a);
        line(buf, matrix, x1,y1,z2, x1,y2,z2, r,g,b,a);
    }

    /** Helper: add two vertices forming one line segment */
    private void line(BufferBuilder buf, Matrix4f m,
                      float x1, float y1, float z1,
                      float x2, float y2, float z2,
                      float r, float g, float b, float a) {
        buf.vertex(m, x1, y1, z1).color(r, g, b, a);
        buf.vertex(m, x2, y2, z2).color(r, g, b, a);
    }
}
