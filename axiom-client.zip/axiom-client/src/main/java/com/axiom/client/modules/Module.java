package com.axiom.client.modules;

import com.axiom.client.AxiomClient;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/**
 * Module – base class for every feature in Axiom.
 *
 * To create a new module:
 *   1. Extend this class
 *   2. Call super(name, description, category, defaultKey)
 *   3. Override onEnable(), onDisable(), onTick() as needed
 *   4. Register it in ModuleManager.registerModules()
 */
public abstract class Module {

    // ── Identity ──────────────────────────────────────────────────────────────
    protected final String   name;
    protected final String   description;
    protected final Category category;

    // ── State ─────────────────────────────────────────────────────────────────
    private boolean enabled = false;

    // ── Keybind ───────────────────────────────────────────────────────────────
    /** GLFW key constant; GLFW_KEY_UNKNOWN means no keybind */
    private int keybind;

    // ── Convenience reference ─────────────────────────────────────────────────
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    // ─────────────────────────────────────────────────────────────────────────
    public Module(String name, String description, Category category, int defaultKey) {
        this.name        = name;
        this.description = description;
        this.category    = category;
        this.keybind     = defaultKey;
    }

    public Module(String name, String description, Category category) {
        this(name, description, category, GLFW.GLFW_KEY_UNKNOWN);
    }

    // ── Lifecycle hooks (override in subclasses) ──────────────────────────────

    /** Called when the module is turned on. Subscribe to events here. */
    public void onEnable()  {}

    /** Called when the module is turned off. Unsubscribe from events here. */
    public void onDisable() {}

    /** Called every client tick while the module is enabled. */
    public void onTick(MinecraftClient client) {}

    // ── Toggle ────────────────────────────────────────────────────────────────

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if (enabled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    // ── Getters / Setters ─────────────────────────────────────────────────────

    public String   getName()        { return name; }
    public String   getDescription() { return description; }
    public Category getCategory()    { return category; }
    public boolean  isEnabled()      { return enabled; }
    public int      getKeybind()     { return keybind; }
    public void     setKeybind(int k){ this.keybind = k; }

    /**
     * Returns a user-friendly keybind label, e.g. "R" or "NONE".
     */
    public String getKeybindName() {
        if (keybind == GLFW.GLFW_KEY_UNKNOWN) return "NONE";
        // GLFW key names are formatted like "GLFW_KEY_R" → strip prefix
        String raw = GLFW.glfwGetKeyName(keybind, 0);
        return raw != null ? raw.toUpperCase() : "KEY " + keybind;
    }

    // ── Module categories ─────────────────────────────────────────────────────

    public enum Category {
        COMBAT   ("Combat",    0xFF5555),  // red
        MOVEMENT ("Movement",  0x55FF55),  // green
        RENDER   ("Render",    0x5555FF),  // blue
        WORLD    ("World",     0xFFAA00),  // orange
        MISC     ("Misc",      0xAAAAAA);  // grey

        public final String displayName;
        public final int    color;          // packed ARGB (no alpha = fully opaque)

        Category(String displayName, int color) {
            this.displayName = displayName;
            this.color       = color;
        }
    }
}
