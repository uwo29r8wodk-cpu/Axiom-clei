package com.axiom.client.modules.impl.render;

import com.axiom.client.modules.Module;
import org.lwjgl.glfw.GLFW;

/**
 * Fullbright – sets the game's gamma to an extremely high value so that
 * dark areas (caves, night) render at full brightness.
 *
 * Vanilla gamma default is 1.0. We set it to 10.0 while enabled and
 * restore it on disable.
 *
 * This is a purely client-side visual tweak — identical to OptiFine's
 * "Night Vision" or the Gamma option slider pushed to maximum.
 */
public class Fullbright extends Module {

    /** Vanilla default gamma value */
    private static final double DEFAULT_GAMMA = 1.0;

    /** Gamma value while Fullbright is active */
    private static final double BRIGHT_GAMMA  = 10.0;

    /** Stores the gamma that was set before we changed it */
    private double previousGamma = DEFAULT_GAMMA;

    public Fullbright() {
        super("Fullbright", "Removes darkness — see clearly in caves and at night",
              Category.RENDER, GLFW.GLFW_KEY_F);
    }

    @Override
    public void onEnable() {
        if (mc.options == null) return;
        // Save current gamma so we can restore it on disable
        previousGamma = mc.options.getGamma().getValue();
        mc.options.getGamma().setValue(BRIGHT_GAMMA);
    }

    @Override
    public void onDisable() {
        if (mc.options == null) return;
        // Restore the player's original gamma setting
        mc.options.getGamma().setValue(previousGamma);
    }
}
