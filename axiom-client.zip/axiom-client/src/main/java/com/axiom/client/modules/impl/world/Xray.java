package com.axiom.client.modules.impl.world;

import com.axiom.client.modules.Module;
import com.axiom.client.utils.Logger;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/**
 * Xray – makes non-valuable blocks render transparently so ores are visible.
 *
 * Implementation note:
 *   True Xray requires a custom BlockRenderManager or shader injection.
 *   The cleanest Fabric approach is to force a chunk rebuild after toggling,
 *   then intercept block rendering in a mixin (see WorldRendererMixin).
 *
 *   This class exposes the static isEnabled() check that the mixin uses
 *   to decide whether to skip rendering a given block.
 *
 * Blocks shown during Xray (everything else is hidden):
 *   Diamond Ore, Emerald Ore, Gold Ore, Iron Ore, Lapis Ore,
 *   Redstone Ore, Coal Ore, Copper Ore, Ancient Debris,
 *   Nether Gold/Quartz Ore — and their deepslate variants.
 */
public class Xray extends Module {

    public Xray() {
        super("Xray", "See valuable ores through stone", Category.WORLD, GLFW.GLFW_KEY_X);
    }

    @Override
    public void onEnable() {
        reloadChunks();
        Logger.info("Xray enabled — reloading chunks");
    }

    @Override
    public void onDisable() {
        reloadChunks();
        Logger.info("Xray disabled — reloading chunks");
    }

    /** Forces Minecraft to rebuild all chunk geometry so the mixin takes effect. */
    private void reloadChunks() {
        if (mc.worldRenderer != null) {
            mc.worldRenderer.reload();
        }
    }

    // ── Static helpers used by the mixin ──────────────────────────────────────

    /**
     * Called by WorldRendererMixin to decide if a block should be hidden.
     * Returns true if the block should be VISIBLE (i.e. it's an ore or air).
     */
    public static boolean shouldShowBlock(net.minecraft.block.BlockState state) {
        String id = net.minecraft.registry.Registries.BLOCK
                        .getId(state.getBlock()).getPath();
        return isOre(id) || state.isAir();
    }

    private static boolean isOre(String blockId) {
        return blockId.contains("_ore")
            || blockId.equals("ancient_debris")
            || blockId.equals("glowstone")
            || blockId.equals("nether_quartz_ore");
    }
}
