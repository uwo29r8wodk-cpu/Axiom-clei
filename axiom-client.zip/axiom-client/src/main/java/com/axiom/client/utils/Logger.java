package com.axiom.client.utils;

import com.axiom.client.AxiomClient;
import org.slf4j.LoggerFactory;

/**
 * Simple logging wrapper around SLF4J.
 * Prefixes every message with "[Axiom]" for easy filtering in console.
 */
public class Logger {

    private static final org.slf4j.Logger LOG =
            LoggerFactory.getLogger(AxiomClient.CLIENT_NAME);

    public static void info(String msg)  { LOG.info("[Axiom] {}", msg); }
    public static void warn(String msg)  { LOG.warn("[Axiom] {}", msg); }
    public static void error(String msg) { LOG.error("[Axiom] {}", msg); }
    public static void debug(String msg) { LOG.debug("[Axiom] {}", msg); }
}
