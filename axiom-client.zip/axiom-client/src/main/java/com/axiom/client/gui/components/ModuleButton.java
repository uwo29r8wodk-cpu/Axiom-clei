package com.axiom.client.gui.components;

import com.axiom.client.gui.ClickGUI;
import com.axiom.client.modules.Module;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * ModuleButton – a single clickable row inside a {@link CategoryPanel}.
 *
 * Left-click  → toggle module on/off
 * Right-click → (future: open settings panel)
 *
 * Visual:
 *   [●] ModuleName    [KEY]
 *    ↑ coloured dot    ↑ dim keybind label
 */
public class ModuleButton {

    private final Module module;
    private int x, y;
    private final int width, height;

    public ModuleButton(Module module, int x, int y, int width, int height) {
        this.module = module;
        this.x      = x;
        this.y      = y;
        this.width  = width;
        this.height = height;
    }

    // ── Rendering ──────────────────────────────────────────────────────────

    public void render(DrawContext ctx, TextRenderer font, int mouseX, int mouseY) {
        boolean hovered = isHovered(mouseX, mouseY);

        // Row background
        if (hovered) {
            ctx.fill(x, y, x + width, y + height, ClickGUI.COL_HOVER);
        }

        // Status indicator dot (small filled square)
        int dotColor = module.isEnabled() ? ClickGUI.COL_MOD_ON : ClickGUI.COL_MOD_OFF;
        ctx.fill(x + 4, y + (height - 4) / 2,
                 x + 8, y + (height + 4) / 2,
                 dotColor);

        // Module name
        int nameColor = module.isEnabled() ? ClickGUI.COL_TEXT : ClickGUI.COL_TEXT_DIM;
        ctx.drawTextWithShadow(font, module.getName(),
                               x + 12, y + (height - 8) / 2, nameColor);

        // Keybind label (right-aligned, very dim)
        String keyLabel = module.getKeybindName();
        if (!keyLabel.equals("NONE")) {
            int labelX = x + width - font.getWidth(keyLabel) - 4;
            ctx.drawTextWithShadow(font, keyLabel, labelX, y + (height - 8) / 2,
                                   0xFF555555);
        }

        // Bottom separator line
        ctx.fill(x + 4, y + height - 1, x + width - 4, y + height, 0xFF1E2433);
    }

    // ── Mouse input ────────────────────────────────────────────────────────

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!isHovered(mouseX, mouseY)) return false;

        if (button == 0) {
            // Left-click: toggle
            module.toggle();
            return true;
        }
        return false;
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    private boolean isHovered(double mx, double my) {
        return mx >= x && mx <= x + width && my >= y && my <= y + height;
    }
}
