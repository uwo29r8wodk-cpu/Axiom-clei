package com.axiom.client.mixins;

import com.axiom.client.AxiomClient;
import com.axiom.client.events.Events;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * GameRendererMixin – fires a RenderTickEvent every frame.
 *
 * We inject at the END of renderWorld so all vanilla rendering has
 * already happened before our code runs (avoids Z-fighting).
 */
@Mixin(GameRenderer.class)
public class GameRendererMixin {

    @Inject(
        method = "renderWorld",
        at = @At("RETURN")
    )
    private void onRenderWorld(float tickDelta, long limitTime,
                               MatrixStack matrices, CallbackInfo ci) {
        if (AxiomClient.getInstance() == null) return;
        AxiomClient.getInstance()
                   .getEventBus()
                   .post(new Events.RenderTickEvent(matrices, tickDelta));
    }
}
