package com.axiom.client.mixins;

import com.axiom.client.AxiomClient;
import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * KeyboardMixin – intercepts GLFW key events to handle module keybind toggles.
 *
 * We only act on GLFW_PRESS (action == 1) so each physical key-press
 * toggles a module exactly once (no repeat/hold firing).
 */
@Mixin(Keyboard.class)
public class KeyboardMixin {

    @Inject(
        method = "onKey",
        at = @At("HEAD")
    )
    private void onKey(long window, int key, int scancode, int action, int modifiers,
                       CallbackInfo ci) {
        // action 1 = GLFW_PRESS, 0 = GLFW_RELEASE, 2 = GLFW_REPEAT
        if (action != 1) return;
        if (AxiomClient.getInstance() == null) return;

        // Forward to ModuleManager to check all module keybinds
        AxiomClient.getInstance().getModuleManager().handleKeyPress(key);
    }
}
