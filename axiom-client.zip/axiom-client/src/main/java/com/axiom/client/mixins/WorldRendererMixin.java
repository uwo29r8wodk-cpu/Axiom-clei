package com.axiom.client.mixins;

import com.axiom.client.AxiomClient;
import com.axiom.client.events.Events;
import com.axiom.client.modules.impl.render.ESP;
import com.axiom.client.modules.impl.render.Tracers;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * WorldRendererMixin – hooks into WorldRenderer to dispatch visual modules.
 *
 * We inject AFTER entities have been rendered so our overlays appear on top.
 */
@Mixin(WorldRenderer.class)
public class WorldRendererMixin {

    /**
     * Called after WorldRenderer finishes rendering entities.
     * We use this to draw ESP boxes and Tracers.
     */
    @Inject(
        method = "render",
        at = @At("RETURN")
    )
    private void onRender(net.minecraft.client.render.RenderTickCounter counter,
                          boolean renderBlockOutline,
                          net.minecraft.client.render.Camera camera,
                          net.minecraft.client.render.GameRenderer gameRenderer,
                          net.minecraft.client.render.LightmapTextureManager lightmapTextureManager,
                          org.joml.Matrix4f positionMatrix,
                          org.joml.Matrix4f projectionMatrix,
                          CallbackInfo ci) {

        if (AxiomClient.getInstance() == null) return;

        float tickDelta = counter.getTickDelta(true);
        MatrixStack matrices = new MatrixStack();

        // Fire WorldRenderEvent for any subscriber modules
        AxiomClient.getInstance()
                   .getEventBus()
                   .post(new Events.WorldRenderEvent(matrices, tickDelta));

        // Directly call render modules that need world-space rendering
        AxiomClient.getInstance().getModuleManager().getModules().forEach(m -> {
            if (!m.isEnabled()) return;

            if (m instanceof ESP esp) {
                esp.render(matrices, tickDelta);
            } else if (m instanceof Tracers tracers) {
                tracers.render(matrices, tickDelta);
            }
        });
    }
}
