package com.axiom.client.modules.impl.movement;

import com.axiom.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/**
 * Sprint – automatically holds sprint so you never have to double-tap W.
 *
 * Uses the vanilla setSprinting() method — this is the same thing the game
 * does when you double-tap forward, so it is completely safe and
 * indistinguishable from normal sprinting.
 */
public class Sprint extends Module {

    public Sprint() {
        super("Sprint", "Automatically sprints while moving forward",
              Category.MOVEMENT, GLFW.GLFW_KEY_V);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null) return;

        // Only sprint if moving forward and not in a menu
        boolean movingForward = client.options.forwardKey.isPressed();
        boolean canSprint     = !client.player.isSneaking()
                             && !client.player.isSubmergedInWater()
                             && client.player.getHungerManager().getFoodLevel() > 6;

        if (movingForward && canSprint) {
            client.player.setSprinting(true);
        }
    }

    @Override
    public void onDisable() {
        // Stop sprinting when module is turned off
        if (mc.player != null) {
            mc.player.setSprinting(false);
        }
    }
}
