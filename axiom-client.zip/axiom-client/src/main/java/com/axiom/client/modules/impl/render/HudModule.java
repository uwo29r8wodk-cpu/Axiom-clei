package com.axiom.client.modules.impl.render;

import com.axiom.client.AxiomClient;
import com.axiom.client.modules.Module;
import com.axiom.client.modules.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.stream.Collectors;

/**
 * HudModule – draws the on-screen HUD overlay.
 *
 * Displays:
 *   - Top-left:  client watermark + FPS counter
 *   - Top-right: sorted list of currently enabled modules (alphabetical)
 *   - Bottom-left: player coordinates and facing direction
 *
 * Called from InGameHudMixin after vanilla HUD renders.
 */
public class HudModule extends Module {

    // ── FPS smoothing ──────────────────────────────────────────────────────
    private int   smoothedFps   = 0;
    private int   fpsTickTimer  = 0;
    private static final int FPS_UPDATE_TICKS = 5; // update display every 5 ticks

    // ── Colors (ARGB) ──────────────────────────────────────────────────────
    private static final int COLOR_WHITE      = 0xFFFFFFFF;
    private static final int COLOR_SHADOW     = 0xFF000000;
    private static final int COLOR_ACCENT     = 0xFF5B8DEF; // Axiom blue
    private static final int COLOR_MODULE_ON  = 0xFFFFFFFF;
    private static final int COLOR_DIM        = 0xFFAAAAAA;

    public HudModule() {
        super("HUD", "Displays client information on screen", Category.RENDER, GLFW.GLFW_KEY_H);
        // HUD is on by default
        setEnabled(true);
    }

    /**
     * Main render method — called by InGameHudMixin every frame.
     *
     * @param context   DrawContext for text/rect drawing
     * @param tickDelta partial tick for smooth animations
     */
    public void render(DrawContext context, float tickDelta) {
        if (mc.player == null || mc.world == null) return;

        TextRenderer font   = mc.textRenderer;
        int          width  = mc.getWindow().getScaledWidth();

        drawWatermark(context, font);
        drawEnabledModules(context, font, width);
        drawCoordinates(context, font);
    }

    // ── Watermark ─────────────────────────────────────────────────────────

    private void drawWatermark(DrawContext ctx, TextRenderer font) {
        String name = AxiomClient.CLIENT_NAME;
        String ver  = " v" + AxiomClient.CLIENT_VERSION;

        // Draw client name in accent colour, version in dim white
        ctx.drawTextWithShadow(font, name, 4, 4, COLOR_ACCENT);
        ctx.drawTextWithShadow(font, ver,  4 + font.getWidth(name), 4, COLOR_DIM);

        // FPS below watermark
        String fps = "FPS: " + smoothedFps;
        ctx.drawTextWithShadow(font, fps, 4, 14, COLOR_WHITE);
    }

    // ── Enabled modules list (top-right) ──────────────────────────────────

    private void drawEnabledModules(DrawContext ctx, TextRenderer font, int screenWidth) {
        ModuleManager mm = AxiomClient.getInstance().getModuleManager();

        // Get enabled modules sorted alphabetically
        List<Module> enabled = mm.getModules().stream()
                .filter(m -> m.isEnabled() && !(m instanceof HudModule))
                .sorted((a, b) -> a.getName().compareToIgnoreCase(b.getName()))
                .collect(Collectors.toList());

        int y = 4;
        for (Module m : enabled) {
            String label = m.getName();
            int    x     = screenWidth - font.getWidth(label) - 4;

            // Category-coloured left bar
            int catColor = 0xFF000000 | m.getCategory().color;
            ctx.fill(x - 2, y, x - 1, y + 10, catColor);

            ctx.drawTextWithShadow(font, label, x, y, COLOR_MODULE_ON);
            y += 11;
        }
    }

    // ── Coordinates (bottom-left) ─────────────────────────────────────────

    private void drawCoordinates(DrawContext ctx, TextRenderer font) {
        if (mc.player == null) return;

        int screenHeight = mc.getWindow().getScaledHeight();

        double x = mc.player.getX();
        double y = mc.player.getY();
        double z = mc.player.getZ();

        String coords = String.format("XYZ: %.1f / %.1f / %.1f", x, y, z);
        String facing = "Facing: " + getFacingDirection();

        ctx.drawTextWithShadow(font, coords, 4, screenHeight - 20, COLOR_WHITE);
        ctx.drawTextWithShadow(font, facing, 4, screenHeight - 10, COLOR_DIM);
    }

    /** Converts yaw to a human-readable cardinal direction. */
    private String getFacingDirection() {
        if (mc.player == null) return "N/A";
        float yaw = mc.player.getYaw() % 360;
        if (yaw < 0) yaw += 360;
        if (yaw < 45  || yaw >= 315) return "North (-Z)";
        if (yaw < 135) return "East (+X)";
        if (yaw < 225) return "South (+Z)";
        return "West (-X)";
    }

    // ── Tick (FPS update) ─────────────────────────────────────────────────

    @Override
    public void onTick(MinecraftClient client) {
        fpsTickTimer++;
        if (fpsTickTimer >= FPS_UPDATE_TICKS) {
            smoothedFps  = client.getCurrentFps();
            fpsTickTimer = 0;
        }
    }
}
