package com.axiom.client.gui;

import com.axiom.client.AxiomClient;
import com.axiom.client.gui.components.CategoryPanel;
import com.axiom.client.modules.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * ClickGUI – the main in-game GUI screen.
 *
 * Layout:
 *   One {@link CategoryPanel} per {@link Module.Category} arranged horizontally.
 *   Each panel lists its modules as toggleable buttons.
 *   Panels are draggable by clicking and dragging their title bar.
 *
 * Opened by pressing the GUI keybind (Right Shift by default).
 * Press Escape or the keybind again to close.
 */
public class ClickGUI extends Screen {

    // One panel per module category
    private final List<CategoryPanel> panels = new ArrayList<>();

    // ── Colour palette ─────────────────────────────────────────────────────
    // These constants are shared with CategoryPanel / ModuleButton
    public static final int COL_BG        = 0xE0151820; // very dark navy, 88% opacity
    public static final int COL_PANEL_HDR = 0xFF1E2433; // slightly lighter navy
    public static final int COL_ACCENT    = 0xFF5B8DEF; // Axiom blue
    public static final int COL_TEXT      = 0xFFEEEEEE; // near-white
    public static final int COL_TEXT_DIM  = 0xFF888888; // grey
    public static final int COL_MOD_ON    = 0xFF2ECC71; // green enabled indicator
    public static final int COL_MOD_OFF   = 0xFF555555; // grey disabled indicator
    public static final int COL_HOVER     = 0xFF2A3245; // row hover highlight

    // ── Panel layout ───────────────────────────────────────────────────────
    private static final int PANEL_WIDTH   = 130;
    private static final int PANEL_X_START = 20;
    private static final int PANEL_Y_START = 40;
    private static final int PANEL_SPACING = 10;

    public ClickGUI() {
        super(Text.literal("Axiom ClickGUI"));
    }

    @Override
    protected void init() {
        panels.clear();

        int x = PANEL_X_START;
        // Create one panel per category, laid out side-by-side
        for (Module.Category category : Module.Category.values()) {
            List<Module> categoryModules = AxiomClient.getInstance()
                    .getModuleManager()
                    .getByCategory(category);

            if (categoryModules.isEmpty()) continue;

            CategoryPanel panel = new CategoryPanel(
                    category,
                    categoryModules,
                    x,
                    PANEL_Y_START,
                    PANEL_WIDTH
            );
            panels.add(panel);
            x += PANEL_WIDTH + PANEL_SPACING;
        }
    }

    // ── Rendering ─────────────────────────────────────────────────────────

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Dim the background (semi-transparent dark overlay)
        context.fill(0, 0, this.width, this.height, 0x88000000);

        // Draw title at top centre
        String title = AxiomClient.CLIENT_NAME + " " + AxiomClient.CLIENT_VERSION;
        int titleX = (this.width - textRenderer.getWidth(title)) / 2;
        context.drawTextWithShadow(textRenderer, title, titleX, 12, COL_ACCENT);

        // Draw hint text
        String hint = "Press ESC or Right Shift to close";
        int hintX = (this.width - textRenderer.getWidth(hint)) / 2;
        context.drawTextWithShadow(textRenderer, hint, hintX, 22, COL_TEXT_DIM);

        // Draw each category panel
        for (CategoryPanel panel : panels) {
            panel.render(context, textRenderer, mouseX, mouseY);
        }

        // Render children (buttons etc.) — must call super AFTER our custom rendering
        super.render(context, mouseX, mouseY, delta);
    }

    // ── Mouse input ───────────────────────────────────────────────────────

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        for (CategoryPanel panel : panels) {
            if (panel.mouseClicked(mouseX, mouseY, button)) {
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (CategoryPanel panel : panels) {
            panel.mouseReleased(mouseX, mouseY, button);
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button,
                                double deltaX, double deltaY) {
        for (CategoryPanel panel : panels) {
            if (panel.mouseDragged(mouseX, mouseY, button, deltaX, deltaY)) {
                return true;
            }
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    // ── Screen behaviour ──────────────────────────────────────────────────

    /** Allow the game to keep running in the background while GUI is open */
    @Override
    public boolean shouldPause() { return false; }
}
