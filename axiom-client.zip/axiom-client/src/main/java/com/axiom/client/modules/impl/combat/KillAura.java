package com.axiom.client.modules.impl.combat;

import com.axiom.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

/**
 * KillAura – automatically attacks the nearest hostile mob within range.
 *
 * By default targets only MobEntity (hostile mobs), NOT other players,
 * to reduce potential for griefing. Range is 4 blocks (vanilla reach).
 *
 * A cooldown timer is enforced to match the vanilla 1.9+ attack speed
 * system so attacks register at full damage.
 */
public class KillAura extends Module {

    private static final double ATTACK_RANGE  = 4.0;   // blocks
    private static final int    ATTACK_DELAY  = 10;    // ticks between attacks (~0.5s)

    private int ticksSinceLastAttack = 0;

    public KillAura() {
        super("KillAura", "Auto-attacks nearby hostile mobs",
              Category.COMBAT, GLFW.GLFW_KEY_K);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        if (client.currentScreen != null) return; // don't attack while in a menu

        ticksSinceLastAttack++;
        if (ticksSinceLastAttack < ATTACK_DELAY) return;

        // Find closest hostile mob within range
        Entity target = null;
        double closest = Double.MAX_VALUE;

        for (Entity entity : client.world.getEntities()) {
            if (entity == client.player) continue;
            if (!entity.isAlive()) continue;

            // Only target hostile mobs (not players or passive animals)
            if (!(entity instanceof MobEntity)) continue;

            double dist = client.player.distanceTo(entity);
            if (dist < ATTACK_RANGE && dist < closest) {
                closest = dist;
                target  = entity;
            }
        }

        if (target != null) {
            client.player.swingHand(Hand.MAIN_HAND);
            client.interactionManager.attackEntity(client.player, target);
            ticksSinceLastAttack = 0;
        }
    }

    @Override
    public void onDisable() {
        ticksSinceLastAttack = 0;
    }
}
