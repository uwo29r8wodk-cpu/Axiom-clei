package com.axiom.client.config;

import com.axiom.client.AxiomClient;
import com.axiom.client.modules.Module;
import com.axiom.client.utils.Logger;
import com.google.gson.*;

import java.io.*;
import java.nio.file.*;

/**
 * ConfigManager – persists module enabled-states and keybinds to disk.
 *
 * Format: JSON file at .minecraft/axiom/config.json
 *
 * Example content:
 * {
 *   "modules": {
 *     "ESP":        { "enabled": true,  "keybind": 90 },
 *     "Fullbright": { "enabled": false, "keybind": 70 }
 *   }
 * }
 *
 * Call load() once at startup (after modules are registered).
 * Call save() any time you want to persist changes.
 * The config auto-saves when the ClickGUI closes.
 */
public class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Path to the config directory inside .minecraft */
    private final Path configDir;
    private final Path configFile;

    public ConfigManager() {
        // Resolve .minecraft/axiom/
        configDir  = net.minecraft.client.MinecraftClient.getInstance()
                        .runDirectory.toPath().resolve("axiom");
        configFile = configDir.resolve("config.json");
    }

    // ── Save ───────────────────────────────────────────────────────────────

    /**
     * Write current module states to disk.
     * Creates the directory if it doesn't exist.
     */
    public void save() {
        try {
            Files.createDirectories(configDir);

            JsonObject root    = new JsonObject();
            JsonObject modules = new JsonObject();

            for (Module m : AxiomClient.getInstance().getModuleManager().getModules()) {
                JsonObject entry = new JsonObject();
                entry.addProperty("enabled", m.isEnabled());
                entry.addProperty("keybind", m.getKeybind());
                modules.add(m.getName(), entry);
            }

            root.add("modules", modules);

            try (Writer writer = Files.newBufferedWriter(configFile)) {
                GSON.toJson(root, writer);
            }

            Logger.info("Config saved to " + configFile);
        } catch (IOException e) {
            Logger.error("Failed to save config: " + e.getMessage());
        }
    }

    // ── Load ───────────────────────────────────────────────────────────────

    /**
     * Read module states from disk and apply them.
     * Silently skips if the config file doesn't exist yet (first run).
     */
    public void load() {
        if (!Files.exists(configFile)) {
            Logger.info("No config file found — using defaults.");
            return;
        }

        try (Reader reader = Files.newBufferedReader(configFile)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();

            if (!root.has("modules")) return;
            JsonObject modules = root.getAsJsonObject("modules");

            for (Module m : AxiomClient.getInstance().getModuleManager().getModules()) {
                if (!modules.has(m.getName())) continue;

                JsonObject entry = modules.getAsJsonObject(m.getName());

                if (entry.has("enabled")) {
                    boolean enabled = entry.get("enabled").getAsBoolean();
                    // setEnabled calls onEnable/onDisable — only change if different
                    if (enabled != m.isEnabled()) {
                        m.setEnabled(enabled);
                    }
                }

                if (entry.has("keybind")) {
                    m.setKeybind(entry.get("keybind").getAsInt());
                }
            }

            Logger.info("Config loaded from " + configFile);
        } catch (Exception e) {
            Logger.error("Failed to load config: " + e.getMessage());
        }
    }
}
