package com.axiom.client.mixins;

import com.axiom.client.AxiomClient;
import com.axiom.client.modules.impl.render.HudModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * InGameHudMixin – called after all vanilla HUD elements have drawn.
 * We render our custom HUD overlay here (watermark, module list, coords).
 */
@Mixin(InGameHud.class)
public class InGameHudMixin {

    @Inject(
        method = "render",
        at = @At("RETURN")
    )
    private void onRenderHud(DrawContext context, RenderTickCounter counter, CallbackInfo ci) {
        if (AxiomClient.getInstance() == null) return;

        float tickDelta = counter.getTickDelta(true);

        // Find HudModule and call its render method
        AxiomClient.getInstance().getModuleManager().getModules().forEach(m -> {
            if (m instanceof HudModule hud && hud.isEnabled()) {
                hud.render(context, tickDelta);
            }
        });
    }
}
