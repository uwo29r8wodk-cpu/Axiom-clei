package com.axiom.client.modules.impl.render;

import com.axiom.client.modules.Module;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.mob.MobEntity;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

/**
 * Tracers – draws a line from the centre of the screen to each nearby entity.
 *
 * Like ESP, this is purely a client-side rendering effect using line primitives.
 * Called from WorldRendererMixin alongside ESP.
 */
public class Tracers extends Module {

    public Tracers() {
        super("Tracers", "Draws lines to nearby entities", Category.RENDER, GLFW.GLFW_KEY_T);
    }

    /**
     * Render tracer lines for all loaded entities.
     *
     * @param matrices  current MatrixStack
     * @param tickDelta partial tick for smooth interpolation
     */
    public void render(MatrixStack matrices, float tickDelta) {
        if (mc.world == null || mc.player == null) return;

        Camera camera = mc.gameRenderer.getCamera();
        double camX = camera.getPos().x;
        double camY = camera.getPos().y;
        double camZ = camera.getPos().z;

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buf = tessellator.begin(
                VertexFormat.DrawMode.DEBUG_LINES,
                VertexFormats.POSITION_COLOR);

        matrices.push();
        matrices.translate(-camX, -camY, -camZ);
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player) continue;
            if (!entity.isAlive()) continue;

            // Colour by entity type
            float r, g, b;
            if (entity instanceof PlayerEntity) {
                r = 1.0f; g = 0.2f; b = 0.2f;
            } else if (entity instanceof MobEntity) {
                r = 1.0f; g = 0.67f; b = 0.0f;
            } else {
                r = 0.5f; g = 1.0f; b = 0.5f;
            }

            // Smooth entity position
            double ex = entity.lastRenderX + (entity.getX() - entity.lastRenderX) * tickDelta;
            double ey = entity.lastRenderY + (entity.getY() - entity.lastRenderY) * tickDelta
                        + entity.getHeight() / 2.0; // mid-body
            double ez = entity.lastRenderZ + (entity.getZ() - entity.lastRenderZ) * tickDelta;

            // Line from camera to entity centre
            buf.vertex(matrix, (float) camX, (float) camY, (float) camZ).color(r, g, b, 0.8f);
            buf.vertex(matrix, (float) ex,   (float) ey,   (float) ez  ).color(r, g, b, 0.8f);
        }

        try {
            BufferRenderer.drawWithGlobalProgram(buf.end());
        } catch (Exception ignored) { }

        matrices.pop();
    }
}
