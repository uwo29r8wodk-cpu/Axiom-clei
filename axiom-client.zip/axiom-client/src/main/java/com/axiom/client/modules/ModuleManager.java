package com.axiom.client.modules;

import com.axiom.client.modules.impl.combat.KillAura;
import com.axiom.client.modules.impl.movement.Sprint;
import com.axiom.client.modules.impl.movement.Fly;
import com.axiom.client.modules.impl.render.*;
import com.axiom.client.modules.impl.world.Xray;
import com.axiom.client.utils.Logger;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.stream.Collectors;

/**
 * ModuleManager – central registry for all Axiom modules.
 *
 * Responsibilities:
 *  - Holds the master list of modules
 *  - Dispatches onTick() to every enabled module
 *  - Handles keybind toggles (checked each tick)
 *  - Provides lookup helpers (by name, by category)
 */
public class ModuleManager {

    /** All registered modules in insertion order */
    private final List<Module> modules = new ArrayList<>();

    // ── Registration ──────────────────────────────────────────────────────────

    /**
     * Instantiate and register every module.
     * Add new modules here — no other file needs to change.
     */
    public void registerModules() {
        // ── Render ────────────────────────────────────────────────────────
        register(new ESP());
        register(new Fullbright());
        register(new HudModule());
        register(new Xray());
        register(new Tracers());

        // ── Movement ──────────────────────────────────────────────────────
        register(new Sprint());
        register(new Fly());

        // ── Combat ────────────────────────────────────────────────────────
        register(new KillAura());

        Logger.info("Registered " + modules.size() + " modules.");
    }

    private void register(Module module) {
        modules.add(module);
        Logger.debug("Registered module: " + module.getName());
    }

    // ── Per-tick dispatch ─────────────────────────────────────────────────────

    /**
     * Called every client tick from AxiomClient.
     * Ticks all enabled modules and checks keybinds.
     */
    public void onTick(MinecraftClient client) {
        // Check all keybinds first
        for (Module m : modules) {
            int key = m.getKeybind();
            if (key != GLFW.GLFW_KEY_UNKNOWN) {
                long handle = client.getWindow().getHandle();
                // Toggle on key press (not hold)
                if (GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS) {
                    // We track "was pressed" state via a simple approach
                    // (full debounce handled in KeyboardMixin)
                }
            }
        }

        // Tick enabled modules
        for (Module m : modules) {
            if (m.isEnabled()) {
                try {
                    m.onTick(client);
                } catch (Exception e) {
                    Logger.error("Error ticking module " + m.getName() + ": " + e.getMessage());
                }
            }
        }
    }

    /**
     * Toggle a module by its GLFW key code.
     * Called from KeyboardMixin when a key is pressed.
     */
    public void handleKeyPress(int key) {
        for (Module m : modules) {
            if (m.getKeybind() == key) {
                m.toggle();
                Logger.debug("Toggled " + m.getName() + " → " + m.isEnabled());
            }
        }
    }

    // ── Lookups ───────────────────────────────────────────────────────────────

    /** Find a module by its exact display name (case-insensitive). */
    public Optional<Module> getModule(String name) {
        return modules.stream()
                      .filter(m -> m.getName().equalsIgnoreCase(name))
                      .findFirst();
    }

    /** Get all modules in a given category. */
    public List<Module> getByCategory(Module.Category category) {
        return modules.stream()
                      .filter(m -> m.getCategory() == category)
                      .collect(Collectors.toList());
    }

    /** @return unmodifiable view of every registered module */
    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    /** Convenience: check if a named module is currently enabled. */
    public boolean isEnabled(String name) {
        return getModule(name).map(Module::isEnabled).orElse(false);
    }
}
