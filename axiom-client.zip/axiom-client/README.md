# Axiom Client — Fabric 1.21.1

A feature-rich Minecraft client mod built with Fabric API.
Clean, well-commented, beginner-friendly code.

---

## Features

| Module       | Category | Default Key | Description                              |
|-------------|----------|-------------|------------------------------------------|
| ESP          | Render   | Z           | Draws coloured boxes around entities     |
| Fullbright   | Render   | F           | Max brightness — see in caves/night      |
| HUD          | Render   | H           | Watermark, FPS, module list, coordinates |
| Tracers      | Render   | T           | Lines from screen centre to entities     |
| Xray         | World    | X           | See ores through stone                   |
| Sprint       | Movement | V           | Auto-sprint while moving forward         |
| Fly          | Movement | G           | Creative-style flight                    |
| KillAura     | Combat   | K           | Auto-attacks nearest hostile mob         |

**GUI keybind:** `Right Shift` — opens the ClickGUI overlay

---

## Setup Instructions

### Prerequisites

1. **Java 21 JDK** — Download from https://adoptium.net/
   - Verify: `java -version` should show 21.x.x

2. **IntelliJ IDEA** (recommended) — https://www.jetbrains.com/idea/
   - Community Edition is free and works perfectly

3. **Git** (optional but recommended) — https://git-scm.com/

---

### Step 1 — Import the project

1. Open IntelliJ IDEA
2. Click **File → Open** and select the `axiom-client` folder
3. IntelliJ will detect the Gradle project and ask to import — click **Trust Project**
4. Wait for Gradle to sync and download dependencies (may take 2–5 minutes on first run)

---

### Step 2 — Generate Minecraft sources (for IDE completion)

In the Gradle panel (right side of IntelliJ), run:
```
axiom-client → Tasks → fabric → genSources
```
Or in terminal:
```bash
./gradlew genSources
```
This gives you full Minecraft source code for navigation and autocomplete.

---

### Step 3 — Run the client

**From IntelliJ:**
- Gradle panel → `axiom-client → Tasks → fabric → runClient`

**From terminal:**
```bash
./gradlew runClient
```

A Minecraft 1.21.1 instance will launch with your mod loaded.

---

### Step 4 — Build a distributable JAR

```bash
./gradlew build
```

Output JAR: `build/libs/axiom-client-1.0.0.jar`

Copy this JAR to `.minecraft/mods/` alongside `fabric-api-*.jar`.

---

## Project Structure

```
axiom-client/
├── build.gradle                    ← Gradle build config
├── gradle.properties               ← Minecraft/mod versions
├── settings.gradle                 ← Gradle settings
└── src/main/
    ├── java/com/axiom/client/
    │   ├── AxiomClient.java         ← Entry point (start here)
    │   ├── config/
    │   │   └── ConfigManager.java   ← Save/load to JSON
    │   ├── events/
    │   │   ├── EventBus.java        ← Pub/sub system
    │   │   └── Events.java          ← Event data classes
    │   ├── gui/
    │   │   ├── ClickGUI.java        ← Main GUI screen
    │   │   └── components/
    │   │       ├── CategoryPanel.java  ← Draggable panel
    │   │       └── ModuleButton.java   ← Clickable module row
    │   ├── mixins/
    │   │   ├── GameRendererMixin.java  ← Render hook
    │   │   ├── WorldRendererMixin.java ← World/ESP hook
    │   │   ├── InGameHudMixin.java     ← HUD hook
    │   │   └── KeyboardMixin.java      ← Keybind hook
    │   ├── modules/
    │   │   ├── Module.java          ← Base class (extend this!)
    │   │   ├── ModuleManager.java   ← Registry + tick dispatch
    │   │   └── impl/
    │   │       ├── combat/
    │   │       │   └── KillAura.java
    │   │       ├── movement/
    │   │       │   ├── Fly.java
    │   │       │   └── Sprint.java
    │   │       ├── render/
    │   │       │   ├── ESP.java
    │   │       │   ├── Fullbright.java
    │   │       │   ├── HudModule.java
    │   │       │   └── Tracers.java
    │   │       └── world/
    │   │           └── Xray.java
    │   └── utils/
    │       └── Logger.java
    └── resources/
        ├── fabric.mod.json          ← Mod metadata
        └── axiom.mixins.json        ← Mixin config
```

---

## Adding a New Module (Tutorial)

1. **Create the class** in the appropriate `impl/` subfolder:

```java
package com.axiom.client.modules.impl.misc;

import com.axiom.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class MyModule extends Module {

    public MyModule() {
        super("MyModule", "Does something cool", Category.MISC, GLFW.GLFW_KEY_M);
    }

    @Override
    public void onEnable() {
        // Runs once when toggled on
    }

    @Override
    public void onDisable() {
        // Runs once when toggled off — ALWAYS clean up here!
    }

    @Override
    public void onTick(MinecraftClient client) {
        // Runs every tick while enabled
        if (client.player == null) return;
        // your logic here
    }
}
```

2. **Register it** in `ModuleManager.registerModules()`:

```java
register(new MyModule());
```

That's it! The module will automatically appear in the ClickGUI, be tickable,
saveable, and respond to its keybind.

---

## Config

Settings are saved to: `.minecraft/axiom/config.json`

The config saves automatically when the game closes.
You can also call `AxiomClient.getInstance().getConfigManager().save()` anywhere.

---

## Common Issues

**"Could not find or load main class"**
→ Re-run `./gradlew genSources` and let Gradle finish fully.

**Mixin errors on startup**
→ Check `axiom.mixins.json` — every class listed must exist in `com.axiom.client.mixins`.

**Black screen / crash on render**
→ The buffer may be submitted empty — ESP/Tracers wrap `buf.end()` in try/catch for this reason.

**Fly doesn't work on servers**
→ Server-side anti-cheat will cancel the movement packets. Fly is for singleplayer/local testing.

---

## Dependencies

| Library        | Version     | Purpose                    |
|---------------|-------------|----------------------------|
| Minecraft      | 1.21.1      | Game                       |
| Fabric Loader  | 0.16.5      | Mod loader                 |
| Fabric API     | 0.102.0     | Events, keybinds, utilities|
| Yarn Mappings  | 1.21.1+b3   | Human-readable names       |
| Gson           | (bundled)   | JSON config serialization  |

---

## License

MIT — free to use, modify, and learn from.
